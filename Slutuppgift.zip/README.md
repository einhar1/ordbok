# Ordbok chrome-tillägg

Ett tillägg som låter dig markera ord på websidor och få tillbaka ordets definition från Wiktionary. Det går även att söka på ord i fritext om du klickar på tillägget.

För att se ordets definition på direkt på wiktionarys hemsida klickar du på aviseringen som kommer upp när du sökt på något.

OBS! Det här tillägget översätter inte ord, utan ger endast tillbaka definitionen av ordet på svenska.

Länk till tillägget på Chrome Web Store: <https://chrome.google.com/webstore/detail/fmbldghfmcoibgafcmkiddiajkbelkbk>
